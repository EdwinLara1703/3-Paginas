const express = require("express");
const path = require("path");
const router = express.Router();

router.get('/pagina1', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/pagina1.html'))
});

router.get('/pagina2', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/pagina2.html'))
});

router.get('/pagina3', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/pagina3.html'))
});

router.get('/styles.css', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/styles.css'))
});

module.exports=router;